import React from 'react';
import Sucursal from '../components/Sucursal';

import imgSoacha from '../assets/images/Soacha.jpg';

const data = [
  {
    nombre: 'Soacha',
    direccion: 'Diagonal 38B#86-28',
    telefono: 3214308206,
    image: imgSoacha,
    ubicacion:
      'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3977.0169243123646!2d-74.20081278567656!3d4.590985543878523!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f9e34c1b1715d%3A0xb23f53d5d437582e!2sDg.%2038b%20%238b-28%2C%20Soacha%2C%20Cundinamarca!5e0!3m2!1ses-419!2sco!4v1622229258988!5m2!1ses-419!2sco',
  },
  {
    nombre: 'La 12',
    direccion: 'Calle 12 # 17-24',
    telefono: 2011157,
    ubicacion:
      'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3976.9386964965606!2d-74.08573278523801!3d4.604999196654597!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f990c8f273f33%3A0xcb4cc049bad2a7f!2sCl.%2012%20%2317-24%2C%20Bogot%C3%A1!5e0!3m2!1ses-419!2sco!4v1622240968444!5m2!1ses-419!2sco',
  },
  {
    nombre: 'Bosa',
    direccion: 'Calle 63 sur # 88-21',
    telefono: 3225922915,
    ubicacion:
      'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3976.827717083824!2d-74.19559168567655!3d4.624807243599765!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f9e74a6a9a979%3A0x3ab00595abb43c8!2sCl.%2063%20Sur%20%2388-21%2C%20Bogot%C3%A1!5e0!3m2!1ses-419!2sco!4v1622241090169!5m2!1ses-419!2sco',
  },
  {
    nombre: 'La 36',
    direccion: 'Cra 36 # 1C 53',
    telefono: 3222319134,
    ubicacion:
      'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3976.9415881638847!2d-74.11221228567653!3d4.604481943767497!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f9939a4c593ab%3A0x5ba38f8a116ccef7!2sCra.%2036%20%231c-53%2C%20Bogot%C3%A1!5e0!3m2!1ses-419!2sco!4v1622241390489!5m2!1ses-419!2sco',
  },
  {
    nombre: 'Giron',
    direccion: 'Bomba Móvil- Av los canneyes Local 1-2',
    telefono: 3178012216,
    ubicacion:
      'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3959.5106611165415!2d-73.16646278567173!3d7.066633518572381!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e683e93e3d35b61%3A0xb44f75d703157868!2sDistribuciones%20Porras!5e0!3m2!1ses!2sco!4v1622247897581!5m2!1ses!2sco',
  },
  {
    nombre: 'La Isla',
    direccion: 'Cl 56 -17C Local 8-10 Interior 289',
    telefono: 3178012216,
    ubicacion:
      'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3959.1648892581297!2d-73.12241438567153!3d7.1068813180790205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e683fc5b53435db%3A0xfa4d88d33bf7d9b4!2sCl.%2056%20%23%2316-17%2C%20Bucaramanga%2C%20Santander!5e0!3m2!1ses!2sco!4v1622247955140!5m2!1ses!2sco',
  },
  {
    nombre: 'Florida Blanca',
    direccion: 'Calle 29# 29-41 Local 3',
    telefono: 3182730037,
    ubicacion:
      'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3959.4670130300356!2d-73.10149338567166!3d7.071726718510069!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e683f7a7769786d%3A0x9775fc7db7d3780a!2sCircunvalar%2029%20%2329-41%2C%20Floridablanca%2C%20Santander!5e0!3m2!1ses!2sco!4v1622248077544!5m2!1ses!2sco',
  },
];
const Sucursales = ({ suc }) => {
  const sucursal = suc.replace('_', ' ');
  const results = data.filter((el) => el.nombre == sucursal);
  const firstObj = results.length > 0 ? results[0] : null;
  return (
    <div>
      <Sucursal
        nombre={firstObj.nombre}
        direccion={firstObj.direccion}
        telefono={firstObj.telefono}
        image={firstObj.image}
        ubicacion={firstObj.ubicacion}
      />
    </div>
  );
};

export default Sucursales;
