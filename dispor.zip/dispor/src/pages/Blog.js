import React from 'react';

const Blog = () => {
  return (
    <div>
      <p>hola</p>
    </div>
  );
};

export default Blog;
