import React from 'react';
import { Helmet } from 'react-helmet';

const Sucursal = ({ nombre, direccion, telefono, image, ubicacion }) => {
  return (
    <>
      <Helmet>
        <title>Suc.{nombre} | Distribuciones Porras La 18</title>
      </Helmet>
      <div className='single'>
        <div
          id='fh5co-title-box'
          style={{
            backgroundImage: ` url(${image})`,
          }}
          data-stellar-background-ratio='0.5'>
          <div className='overlay'></div>
          <div className='page-title'>
            <img
              src='https://i.ibb.co/0q4mCp4/Icono-Distribuciones-Porras-La-18-3.png'
              alt='Free HTML5 by FreeHTMl5.co'
            />
            <h2>Sucursal de {nombre}</h2>
          </div>
        </div>

        <div
          id='fh5co-single-content'
          className='container-fluid pb-4 pt-4 paddding'>
          <div className='container paddding'>
            <div className='row mx-0'>
              <div
                className='col-7 animate-box'
                data-animate-effect='fadeInLeft'>
                <p>
                  Nos encontramos ubicados en la <strong>{direccion}</strong>,
                  aqui puedes encontras productos como licores, elementos de
                  aseo, gaseosas al por mayor y detal asi como algunos abarrotes
                  tales como aceite, leche, pasta, arroz, café, salchichas.
                </p>
                <h3>Contactanos</h3>
                <p>
                  puedes contactarnos llamando a siguente numero{' '}
                  <strong>
                    <a href={`tel:+${telefono}`}>{telefono}</a>
                  </strong>{' '}
                  y llevaremos tu pedido a domicilio O escribenos a nuestro
                  whatsapp para atenderte.
                </p>
                <div>
                  <h3>Como encontrarnos!</h3>
                  <br />
                  <iframe
                    src={ubicacion}
                    width='600'
                    height='450'
                    loading='lazy'
                    style={{
                      border: '0px',
                    }}></iframe>
                </div>
              </div>

              <div
                className='col-4 animate-box'
                data-animate-effect='fadeInRight'>
                <div className='col-12 text-center contact_margin_svnit '>
                  <div className='text-center fh5co_heading py-2'>
                    Contactanos
                  </div>
                </div>
                <div className='row'>
                  <div className='col-12 '>
                    <form className='row' id='fh5co_contact_form'>
                      <div className='col-12 py-2'>
                        <input
                          type='text'
                          className='form-control fh5co_contact_text_box'
                          placeholder='Enter Your Name'
                        />
                      </div>
                      <div className='col-12 py-2'>
                        <input
                          type='text'
                          className='form-control fh5co_contact_text_box'
                          placeholder='E-mail'
                        />
                      </div>
                      <div className='col-12 py-2'>
                        <input
                          type='text'
                          className='form-control fh5co_contact_text_box'
                          placeholder='Subject'
                        />
                      </div>
                      <div className='col-12 py-2'>
                        <textarea
                          className='form-control fh5co_contacts_message'
                          placeholder='Message'></textarea>
                      </div>
                      <div className='col-12 py-2 text-center'>
                        {' '}
                        <a href='#' className='btn contact_btn'>
                          Send Message
                        </a>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Sucursal;
