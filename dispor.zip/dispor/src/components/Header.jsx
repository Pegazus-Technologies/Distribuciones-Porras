import React from 'react';
import logo from '../assets/images/logo.png';
import { Link } from '@reach/router';
import Navbar from './Navbar';

const Header = () => {
  const meses = [
    'Enero',
    'Febrero',
    'Marzo',
    'Abril',
    'Mayo',
    'Junio',
    'Julio',
    'Agosto',
    'Septiembre',
    'Octubre',
    'Noviembre',
    'Diciembre',
  ];
  const hoy = new Date();
  const fecha =
    hoy.getDate() + ' de ' + meses[hoy.getMonth()] + ' de ' + hoy.getFullYear();
  return (
    <>
      <div className='container-fluid fh5co_header_bg'>
        <div className='container'>
          <div className='row'>
            <div className='col-12 fh5co_mediya_center'>
              <a href='#' className='color_fff fh5co_mediya_setting'>
                <i className='fa fa-clock-o'></i>&nbsp;&nbsp;&nbsp;{fecha}
              </a>
              <div className='d-inline-block fh5co_trading_posotion_relative'>
                <a href='#' className='treding_btn'>
                  ¡Promociones!
                </a>
                <div className='fh5co_treding_position_absolute'></div>
              </div>
              <a href='#' className='color_fff fh5co_mediya_setting'>
                Llega la nueva línea de productos de aseo
              </a>
            </div>
          </div>
        </div>
      </div>
      <div className='container-fluid'>
        <div className='container'>
          <div className='row'>
            <div className='col-12 col-md-3 fh5co_padding_menu'>
              <Link to='/'>
                <img src={logo} alt='img' className='fh5co_logo_width' />
              </Link>
            </div>
            <div className='col-12 col-md-9 align-self-center fh5co_mediya_right'>
              <div className='text-center d-inline-block'>
                <a
                  href='https://twitter.com/fh5co'
                  target='_blank'
                  className='fh5co_display_table'>
                  <div className='fh5co_verticle_middle'>
                    <i className='fa fa-twitter'></i>
                  </div>
                </a>
              </div>
              <div className='text-center d-inline-block'>
                <a
                  href='https://fb.com/fh5co'
                  target='_blank'
                  className='fh5co_display_table'>
                  <div className='fh5co_verticle_middle'>
                    <i className='fa fa-facebook'></i>
                  </div>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Navbar />
    </>
  );
};

export default Header;
