import React from 'react';
import Soacha from '../assets/images/Soacha.jpg';
import Productos from '../assets/images/Prodcutos.jpg';
import bebidas from '../assets/images/bebidas.jpg';
import licores from '../assets/images/Licores.jpg';
import aseo from '../assets/images/aseo.jpg';

const Main = () => {
  return (
    <div className='container-fluid paddding mb-5'>
      <div className='row mx-0'>
        <div
          className='col-md-6 col-12 paddding animate-box'
          data-animate-effect='fadeIn'>
          <div className='fh5co_suceefh5co_height'>
            <img src={Soacha} alt='img' />
            <div className='fh5co_suceefh5co_height_position_absolute'></div>
            <div className='fh5co_suceefh5co_height_position_absolute_font'>
              <div className=''>
                <a href='single.html' className='fh5co_good_font'>
                  Nuestra Sucursal de Soacha
                </a>
              </div>
            </div>
          </div>
        </div>
        <div className='col-md-6'>
          <div className='row'>
            <div
              className='col-md-6 col-6 paddding animate-box'
              data-animate-effect='fadeIn'>
              <div className='fh5co_suceefh5co_height_2'>
                <img src={Productos} alt='img' />
                <div className='fh5co_suceefh5co_height_position_absolute'></div>
                <div className='fh5co_suceefh5co_height_position_absolute_font_2'>
                  <div className=''>
                    <a href='single.html' className='fh5co_good_font_2'>
                      Podras encontrar todo lo
                      <br /> que necesites para tu hogar
                    </a>
                  </div>
                </div>
              </div>
            </div>
            <div
              className='col-md-6 col-6 paddding animate-box'
              data-animate-effect='fadeIn'>
              <div className='fh5co_suceefh5co_height_2'>
                <img src={bebidas} alt='img' />
                <div className='fh5co_suceefh5co_height_position_absolute'></div>
                <div className='fh5co_suceefh5co_height_position_absolute_font_2'>
                  <div className=''>
                    <a href='single.html' className='fh5co_good_font_2'>
                      Contamos con gran variedad
                      <br />
                      de bebdias azucaradas
                    </a>
                  </div>
                </div>
              </div>
            </div>
            <div
              className='col-md-6 col-6 paddding animate-box'
              data-animate-effect='fadeIn'>
              <div className='fh5co_suceefh5co_height_2'>
                <img src={licores} alt='img' />
                <div className='fh5co_suceefh5co_height_position_absolute'></div>
                <div className='fh5co_suceefh5co_height_position_absolute_font_2'>
                  <div className=''>
                    <a href='single.html' className='fh5co_good_font_2'>
                      Tambien enotraras la mejor <br /> seleccion de licores
                    </a>
                  </div>
                </div>
              </div>
            </div>
            <div
              className='col-md-6 col-6 paddding animate-box'
              data-animate-effect='fadeIn'>
              <div className='fh5co_suceefh5co_height_2'>
                <img src={aseo} alt='img' />
                <div className='fh5co_suceefh5co_height_position_absolute'></div>
                <div className='fh5co_suceefh5co_height_position_absolute_font_2'>
                  <div className=''>
                    <a href='single.html' className='fh5co_good_font_2'>
                      Los mejores productos de <br />
                      aseo personal y del hogar
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Main;
