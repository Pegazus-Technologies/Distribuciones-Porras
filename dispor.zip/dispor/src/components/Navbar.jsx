import React from 'react';
import NavLink from './NavLink';
import ListLink from './ListLink';

import { Link } from '@reach/router';

const Navbar = () => {
  return (
    <div className='container-fluid bg-faded fh5co_padd_mediya padding_786'>
      <div className='container padding_786'>
        <nav className='navbar navbar-toggleable-md navbar-light '>
          <button
            className='navbar-toggler navbar-toggler-right mt-3'
            type='button'
            data-toggle='collapse'
            data-target='#navbarSupportedContent'
            aria-controls='navbarSupportedContent'
            aria-expanded='false'
            aria-label='Toggle navigation'>
            <span className='fa fa-bars'></span>
          </button>
          <Link to='/' className='navbar-brand'>
            <img
              src='images/logo.png'
              alt='img'
              className='mobile_logo_width'
            />
          </Link>
          <div className='collapse navbar-collapse' id='navbarSupportedContent'>
            <ul className='navbar-nav mr-auto'>
              <li className='nav-item '>
                <NavLink to='/'>
                  Inicio <span className='sr-only'></span>
                </NavLink>
              </li>
              <li className='nav-item '>
                <NavLink to='/blog'>
                  Blog <span className='sr-only'></span>
                </NavLink>
              </li>
              <li className='nav-item '>
                <NavLink to='/products'>
                  Productos <span className='sr-only'></span>
                </NavLink>
              </li>
              <li className='nav-item dropdown'>
                <a
                  className='nav-link dropdown-toggle'
                  href='#'
                  id='dropdownMenuButton2'
                  data-toggle='dropdown'
                  aria-haspopup='true'
                  aria-expanded='false'>
                  Sucursales <span className='sr-only'></span>
                </a>
                <div
                  className='dropdown-menu'
                  aria-labelledby='dropdownMenuLink_1'>
                  <ListLink className='dropdown-item' to='Sucursales/Soacha'>
                    Soacha
                  </ListLink>
                  <ListLink className='dropdown-item' to='Sucursales/Bosa'>
                    Bosa
                  </ListLink>
                  <ListLink className='dropdown-item' to='Sucursales/La_36'>
                    La 36
                  </ListLink>
                  <ListLink className='dropdown-item' to='Sucursales/La_12'>
                    La 12
                  </ListLink>
                  <ListLink
                    className='dropdown-item'
                    to='Sucursales/Florida_Blanca'>
                    Florida blanca
                  </ListLink>
                  <ListLink className='dropdown-item' to='Sucursales/Giron'>
                    Giron
                  </ListLink>
                  <ListLink className='dropdown-item' to='Sucursales/La_Isla'>
                    La isla
                  </ListLink>
                </div>
              </li>
              <li className='nav-item '>
                <NavLink to='/about-me'>
                  Sobre nosotros <span className='sr-only'></span>
                </NavLink>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </div>
  );
};

export default Navbar;
