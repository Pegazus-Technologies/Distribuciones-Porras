import React from 'react';
import { Link } from '@reach/router';

const ListLink = (props) => (
  <Link
    {...props}
    getProps={({ isCurrent }) => {
      return {
        className: `dropdown-item ${isCurrent ? 'active' : ''}`,
      };
    }}
  />
);

export default ListLink;
