import React from 'react';
import { Router } from '@reach/router';
import Header from './Header';
import Home from '../pages/Home';
import Blog from '../pages/Blog';
import Sucursales from '../pages/Sucursales';
import Footer from './Footer';

const App = () => {
  return (
    <>
      <Header />
      <Router>
        <Home path='/' />
        <Blog path='/blog' />
        <Sucursales path='/Sucursales/:suc' />
      </Router>
      <Footer />
    </>
  );
};

export default App;
